# FSS ANKOR Final Checklist

## 입력칸별 값

- 제목: `FSS_ANKOR_TITLE_20260309.txt`
- 신고내용: `FSS_ANKOR_ONLINE_PASTE_20260309.txt`
- 신고경위: `FSS_ANKOR_REPORT_PATH_20260309.txt`
- 첨부파일: `fss_ankor_bundle_20260309.zip`

## 체크값

- 종목구분: `유가증권`
- 정치테마주 관련 여부: `관련 없음`
- 불공정행위: `시세조종`
- 업체명: `한국ANKOR유전`
- 불공정행위자 인적사항: `성명불상(관련 계좌군 의심)`

## 제출 전 확인

1. 본문에 백틱, 따옴표 깨짐, 링크 누락이 없는지 확인
2. 첨부파일명이 `fss_ankor_bundle_20260309.zip`인지 확인
3. 타기관 신고 여부는 실제 제출 상태에 맞게 선택
4. 이메일 주소와 비밀번호 분실 복구용 정보 재확인
